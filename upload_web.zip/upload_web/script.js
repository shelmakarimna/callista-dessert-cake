/* ==========================================================================
   Callista Dessert & Cake — script.js
   Vanilla JS: mobile navbar toggle, active-link tracking, footer year.
   ========================================================================== */
(function () {
  'use strict';

  /* ---------- Footer year ---------- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Mobile navbar (hamburger) ---------- */
  var burgerBtn = document.getElementById('burgerBtn');
  var navMenu = document.getElementById('navMenu');

  function closeMenu() {
    navMenu.classList.remove('is-open');
    burgerBtn.setAttribute('aria-expanded', 'false');
  }

  function toggleMenu() {
    var isOpen = navMenu.classList.toggle('is-open');
    burgerBtn.setAttribute('aria-expanded', String(isOpen));
  }

  if (burgerBtn && navMenu) {
    burgerBtn.addEventListener('click', toggleMenu);

    // Close the mobile menu after a link is tapped.
    navMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', closeMenu);
    });

    // Close if the user clicks/taps outside the open menu.
    document.addEventListener('click', function (event) {
      var clickedInsideNav = navMenu.contains(event.target) || burgerBtn.contains(event.target);
      if (!clickedInsideNav && navMenu.classList.contains('is-open')) {
        closeMenu();
      }
    });

    // Close on Escape for keyboard users.
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && navMenu.classList.contains('is-open')) {
        closeMenu();
        burgerBtn.focus();
      }
    });

    // Collapse the mobile menu automatically if the viewport grows back
    // to desktop size while the menu was left open.
    window.addEventListener('resize', function () {
      if (window.innerWidth > 720) closeMenu();
    });
  }

  /* ---------- Active nav link on scroll ---------- */
  var sections = Array.prototype.slice.call(
    document.querySelectorAll('section[id], header[id]')
  );
  var navLinks = Array.prototype.slice.call(
    document.querySelectorAll('.navbar__group a')
  );

  function setActiveLink() {
    var scrollPos = window.scrollY + window.innerHeight * 0.35;
    var current = sections[0];

    sections.forEach(function (section) {
      if (section.offsetTop <= scrollPos) current = section;
    });

    if (!current) return;
    var currentId = current.getAttribute('id');

    navLinks.forEach(function (link) {
      var href = link.getAttribute('href') || '';
      var isMatch = href === '#' + currentId;
      link.classList.toggle('is-active', isMatch);
    });
  }

  var scrollTicking = false;
  window.addEventListener('scroll', function () {
    if (!scrollTicking) {
      window.requestAnimationFrame(function () {
        setActiveLink();
        scrollTicking = false;
      });
      scrollTicking = true;
    }
  });
  setActiveLink();
})();

// Filter kota untuk bagian "Lokasi Kami".
(function () {
  const tabs = document.querySelectorAll('.branches__tab');
  const panels = document.querySelectorAll('.branches__panel');
  if (!tabs.length || !panels.length) return;

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.target;

      tabs.forEach((t) => {
        const active = t === tab;
        t.classList.toggle('is-active', active);
        t.setAttribute('aria-selected', String(active));
      });

      panels.forEach((panel) => {
        panel.classList.toggle('is-hidden', panel.dataset.panel !== target);
      });
    });
  });
})();

//BUAT CHATBOT
const chatbotToggle = document.getElementById("chatbotToggle");
const chatbot = document.getElementById("chatbot");
const chatInput = document.getElementById("chatInput");
const sendButton = document.getElementById("sendButton");
const chatbotBody = document.getElementById("chatbotBody");

chatbotToggle.addEventListener("click", function () {

  chatbot.classList.toggle("active");

  chatbotToggle.classList.toggle("active");

});

async function sendMessage() {

  const message = chatInput.value.trim();
  if (message === "") {
    return;
  }
  const userMessage = document.createElement("div");
  userMessage.classList.add(
    "message",
    "user-message"
  );

  userMessage.textContent = message;
  chatbotBody.appendChild(userMessage);
  chatInput.value = "";
  chatbotBody.scrollTop =
    chatbotBody.scrollHeight;

  try {
    const response = await fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: message })
    });

    const data = await response.json();

    const botMessage = document.createElement("div");
    botMessage.classList.add("message", "bot-message");
    botMessage.textContent =
      data.reply || data.error || "Maaf, ada yang salah. Coba lagi ya! 💗";

    chatbotBody.appendChild(botMessage);

  } catch (error) {
    console.error(error);

    const botMessage = document.createElement("div");
    botMessage.classList.add("message", "bot-message");
    botMessage.textContent =
      "Waduh, Callista's AI lagi gangguan koneksi nih. Coba tanya lagi sebentar lagi ya! 💗";

    chatbotBody.appendChild(botMessage);
  }

  chatbotBody.scrollTop = chatbotBody.scrollHeight;
}

sendButton.addEventListener(
  "click",
  sendMessage
);

chatInput.addEventListener(
  "keydown",
  function (event) {

    if (event.key === "Enter") {
      sendMessage();

    }
  }
);