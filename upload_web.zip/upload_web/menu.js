const categories = [
  {
    id: 'mochi',
    name: 'Mochi',
    desc: 'Lembut, kenyal, dan manis dalam setiap gigitan.',
    img: 'assets/mochi.png',
    emoji: '🍡',
    banner: ['assets/banner-mochi-1.jpg', 'assets/banner-mochi-2.jpg', 'assets/banner-mochi-3.jpg', 'assets/banner-mochi-4.jpg'],
    items: [
      { name: 'Anggur', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah anggur', img: 'assets/mochi-anggur.png' },
      { name: 'Stroberi', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah stroberi', img: 'assets/mochi-stroberi.png' },
      { name: 'Matcha', price: 5500, desc: 'Mochi lembut dengan isian krim matcha', img: 'assets/mochi-matcha.png' },
      { name: 'Coklat', price: 5500, desc: 'Mochi lembut dengan isian krim coklat', img: 'assets/mochi-coklat.png' },
      { name: 'Taro', price: 5500, desc: 'Mochi lembut dengan isian krim taro', img: 'assets/mochi-taro.png' },
      { name: 'Mangga', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah mangga', img: 'assets/mochi-mangga.png' },
      { name: 'Pistachio', price: 6500, desc: 'Mochi lembut dengan isian krim pistachio', img: 'assets/mochi-pistachio.png' },
      { name: 'Tiramisu', price: 6500, desc: 'Mochi lembut dengan isian krim tiramisu', img: 'assets/mochi-tiramisu.png' },
      { name: 'Anggur', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah anggur', img: 'assets/mochi-anggur.png' },
      { name: 'Stroberi', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah stroberi', img: 'assets/mochi-stroberi.png' },
      { name: 'Matcha', price: 5500, desc: 'Mochi lembut dengan isian krim matcha', img: 'assets/mochi-matcha.png' },
      { name: 'Coklat', price: 5500, desc: 'Mochi lembut dengan isian krim coklat', img: 'assets/mochi-coklat.png' },
      { name: 'Taro', price: 5500, desc: 'Mochi lembut dengan isian krim taro', img: 'assets/mochi-taro.png' },
      { name: 'Mangga', price: 5500, desc: 'Mochi lembut dengan isian krim dan buah mangga', img: 'assets/mochi-mangga.png' },
      { name: 'Pistachio', price: 6500, desc: 'Mochi lembut dengan isian krim pistachio', img: 'assets/mochi-pistachio.png' },
      { name: 'Tiramisu', price: 6500, desc: 'Mochi lembut dengan isian krim tiramisu', img: 'assets/mochi-tiramisu.png' }
    ]
  },
  {
    id: 'crepe',
    name: 'Crepe Cake',
    desc: 'Lapisan crepe lembut dengan cream yang manis.',
    img: 'assets/crepe-cake.png',
    emoji: '🍰',
    banner: [],
    items: [
      { name: 'Tiramisu', price: 18000, desc: 'Crepe cake lapis dengan krim tiramisu', img: 'assets/crepe-tiramisu.png' },
      { name: 'Coklat', price: 18000, desc: 'Crepe cake lapis dengan krim coklat', img: 'assets/crepe-coklat.png' },
      { name: 'Matcha', price: 18000, desc: 'Crepe cake lapis dengan krim matcha', img: 'assets/crepe-matcha.png' },
      { name: 'Stroberi', price: 18000, desc: 'Crepe cake lapis dengan krim stroberi', img: 'assets/crepe-stroberi.png' },
      { name: 'Red Velvet', price: 20000, desc: 'Crepe cake lapis dengan krim red velvet', img: 'assets/crepe-redvelvet.png' },
      { name: 'Taro', price: 18000, desc: 'Crepe cake lapis dengan krim taro', img: 'assets/crepe-taro.png' },
      { name: 'Mangga', price: 20000, desc: 'Crepe cake lapis dengan krim dan mangga', img: 'assets/crepe-mangga.png' },
      { name: 'Oreo', price: 20000, desc: 'Crepe cake lapis dengan krim oreo', img: 'assets/crepe-oreo.png' }
    ]
  },
  {
    id: 'mochicake',
    name: 'Mochi Cake',
    desc: 'Mochi kenyal yang disusun cantik menjadi bentuk cake.',
    img: 'assets/mochi-cake.png',
    emoji: '🎂',
    banner: [],
    items: [
      { name: 'Mochi Cake Mini', price: 55000, desc: 'Isi 6 mochi aneka rasa dalam kotak cantik', img: 'assets/mochicake-mini.png' },
      { name: 'Mochi Cake Medium', price: 85000, desc: 'Isi 9 mochi aneka rasa dalam kotak cantik', img: 'assets/mochicake-medium.png' },
      { name: 'Mochi Cake Large', price: 120000, desc: 'Isi 12 mochi aneka rasa dalam kotak cantik', img: 'assets/mochicake-large.png' },
      { name: 'Mochi Cake Special', price: 150000, desc: 'Mochi cake dengan topping buah dan hiasan spesial', img: 'assets/mochicake-special.png' }
    ]
  }, 
  {
    id: 'dubai',
    name: 'Dubai Chewy',
    desc: 'Mochi kenyal yang disusun cantik menjadi bentuk cake.',
    img: 'assets/mochi-cake.png',
    emoji: '🎂',
    banner: [],
    items: [
      { name: 'Dubai Chewy Cookie', price: 28000, desc: 'Isi 6 mochi aneka rasa dalam kotak cantik', img: 'assets/mochicake-mini.png' },
      { name: 'Dubai Chewy Ube', price: 25000, desc: 'Isi 9 mochi aneka rasa dalam kotak cantik', img: 'assets/mochicake-medium.png' }
    ]
  }
];

// ====== STATE ======
let current = 0;

const $cards = document.getElementById('categoryCards');
const $grid = document.getElementById('productGrid');
const $bannerTitle = document.getElementById('bannerTitle');
const $bannerImages = document.getElementById('bannerImages');

// ====== HELPERS ======
const formatPrice = n => n.toLocaleString('id-ID');

// Gambar dengan fallback emoji kalau file belum ada
function imgWithFallback(src, emoji, alt) {
  const wrap = document.createElement('span');
  wrap.style.display = 'contents';
  const img = new Image();
  img.src = src;
  img.alt = alt;
  img.loading = 'lazy';
  img.onerror = () => { wrap.textContent = emoji; };
  wrap.appendChild(img);
  return wrap;
}

// ====== RENDER ======
function renderCategoryCards() {
  $cards.innerHTML = '';
  categories.forEach((cat, i) => {
    const card = document.createElement('article');
    card.className = 'cat-card' + (i === current ? ' active' : '');
    card.innerHTML = `<h3>${cat.name}</h3><div class="cat-img"></div><p>${cat.desc}</p>`;
    card.querySelector('.cat-img').appendChild(imgWithFallback(cat.img, cat.emoji, cat.name));
    card.addEventListener('click', () => {
      setCategory(i);
      document.querySelector('.menu').scrollIntoView({ behavior: 'smooth' });
    });
    $cards.appendChild(card);
  });
}

function renderBanner(cat) {
  $bannerTitle.textContent = cat.name;
  $bannerImages.innerHTML = '';
  const fallbackEmoji = [cat.emoji, '🍬', '🍫', '🍇'];
  for (let i = 0; i < 4; i++) {
    const cell = document.createElement('div');
    if (cat.banner[i]) cell.appendChild(imgWithFallback(cat.banner[i], fallbackEmoji[i], cat.name));
    else cell.textContent = fallbackEmoji[i];
    $bannerImages.appendChild(cell);
  }
}

function renderProducts(cat) {
  $grid.innerHTML = '';
  cat.items.forEach(item => {
    const el = document.createElement('article');
    el.className = 'product';
    el.innerHTML = `
      <div class="product-img"></div>
      <div class="product-head">
        <h3 class="product-name">${item.name}</h3>
        <span class="price">${formatPrice(item.price)}</span>
      </div>
      <p class="product-desc">${item.desc}</p>`;
    el.querySelector('.product-img').appendChild(imgWithFallback(item.img, cat.emoji, item.name));
    $grid.appendChild(el);
  });
}

function setCategory(i) {
  current = (i + categories.length) % categories.length;
  const cat = categories[current];
  renderBanner(cat);
  renderProducts(cat);
  document.querySelectorAll('.cat-card').forEach((c, idx) => c.classList.toggle('active', idx === current));
}

// ====== EVENTS ======
document.getElementById('prevBtn').addEventListener('click', () => setCategory(current - 1));
document.getElementById('nextBtn').addEventListener('click', () => setCategory(current + 1));

const nav = document.querySelector('.nav');
document.getElementById('navToggle').addEventListener('click', () => nav.classList.toggle('open'));

// ====== INIT ======
renderCategoryCards();
setCategory(0);